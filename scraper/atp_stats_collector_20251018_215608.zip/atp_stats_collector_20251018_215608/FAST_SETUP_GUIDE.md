# ATP Stats Collector - Quick Setup Guide

## 📦 Setup on New Computer

### 1. Install Python Dependencies
```bash
pip install cloudscraper beautifulsoup4 lxml
```

### 2. Copy Required Files
Transfer these files to the new computer:
```
atp_stats_collector_fast.py          # The fast collector script
progress/atp_all_matches.csv         # Input data (2,441 matches)
```

### 3. Create Directory Structure
```bash
mkdir -p progress
```

### 4. Run the Collector
```bash
python3 atp_stats_collector_fast.py
```

Or run in background:
```bash
nohup python3 atp_stats_collector_fast.py > stats_collection.log 2>&1 &
```

---

## ⚡ Performance Improvements

### Optimizations Made:
- **Delay reduced**: 1-2 seconds (was 5-10 seconds)
- **Fewer retries**: 2 attempts (was 3)
- **Faster retry**: 30s wait (was 60s)
- **Real-time rate tracking**: Shows matches/second
- **ETA calculation**: Estimates completion time

### Expected Performance:
- **Old version**: ~4-7 hours (5-10s delays)
- **Fast version**: **~1-2 hours** (1-2s delays)
- **Speed**: ~0.5-1 matches/second
- **Total matches**: 2,441

---

## 📊 Output

### Output File:
`progress/atp_match_statistics.csv`

### Columns (40 total):
1. Match info (8): tournament, dates, round, players, score, time
2. Player 1 stats (16): aces, serves, returns, points, errors, etc.
3. Player 2 stats (16): same statistics for second player
4. Stats URL (1): source page

---

## 🔄 Resume Capability

The script automatically saves progress every 50 matches to:
`progress/stats_progress_fast.json`

If interrupted:
- Just run the script again
- It will resume from where it stopped
- Already processed matches are skipped

---

## 📈 Live Monitoring

While running, you'll see:
```
[1234/2441] Australian Open - Sinner vs Djokovic
  Rate: 0.67 matches/sec | ETA: 30.1 min | Success: 1150 | Failed: 84
  ✓ Stats collected
```

This shows:
- **Progress**: Current match / Total matches
- **Rate**: Processing speed (matches per second)
- **ETA**: Estimated time remaining
- **Success/Failed**: Counts of successful/failed collections

---

## 💡 Tips for Success

### 1. Use Different IP Address
Run on different computer/network to avoid rate limiting from your current IP.

### 2. Monitor the Log
```bash
tail -f stats_collection.log
```

### 3. If You Get Rate Limited (HTTP 429)
The script will:
- Automatically retry with increasing delays
- Wait 30s, 60s between retries
- Skip match after 2 failed attempts
- Continue with next match

### 4. Adjust Speed If Needed
Edit `atp_stats_collector_fast.py`:
```python
# Line 17-18
MIN_DELAY = 1.0  # Increase to 2.0 or 3.0 if getting rate limited
MAX_DELAY = 2.0  # Increase to 4.0 or 5.0 if getting rate limited
```

### 5. Check Progress Anytime
```bash
# Count successful collections
wc -l progress/atp_match_statistics.csv

# View last 5 collected
tail -n 5 progress/atp_match_statistics.csv
```

---

## 🚀 Quick Start (Copy-Paste)

On the new computer:

```bash
# 1. Install dependencies
pip install cloudscraper beautifulsoup4 lxml

# 2. Create directory
mkdir -p progress

# 3. Copy files (adjust path as needed)
# - atp_stats_collector_fast.py
# - progress/atp_all_matches.csv

# 4. Run collector
python3 atp_stats_collector_fast.py

# Or run in background
nohup python3 atp_stats_collector_fast.py > stats_collection.log 2>&1 &

# 5. Monitor progress
tail -f stats_collection.log
```

---

## 📋 Checklist

Before running:
- [ ] Python 3.7+ installed
- [ ] Dependencies installed (`cloudscraper`, `beautifulsoup4`, `lxml`)
- [ ] `atp_all_matches.csv` file present
- [ ] `progress/` directory exists
- [ ] Stable internet connection
- [ ] Different IP address (not rate limited)

After completion:
- [ ] Check `progress/atp_match_statistics.csv` exists
- [ ] Verify row count: `wc -l progress/atp_match_statistics.csv`
- [ ] Expected: ~2,400+ rows (header + successful matches)

---

## 🆘 Troubleshooting

### "Import cloudscraper could not be resolved"
```bash
pip install cloudscraper
```

### "File not found: progress/atp_all_matches.csv"
Copy the CSV file from this computer to the new one.

### Getting HTTP 429 immediately
Your new computer's IP might be rate limited. Try:
1. Wait 1-2 hours
2. Use VPN or different network
3. Increase delays in the script

### Script stops/crashes
Just run it again - it will resume automatically.

---

## 📊 Expected Results

After 1-2 hours, you should have:
- **~2,400+ matches** with complete statistics
- **40 columns** of data per match
- **~78,000 data points** total (16 stats × 2 players × 2,441 matches)

Ready for analysis! 🎾📈

#!/bin/bash
echo "=========================================="
echo "ATP Stats Collector - Quick Start"
echo "=========================================="
echo ""

# Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $python_version"

# Install dependencies
echo ""
echo "Installing dependencies..."
pip install -r requirements.txt

# Check if CSV exists
if [ ! -f "progress/atp_all_matches.csv" ]; then
    echo ""
    echo "✗ Error: progress/atp_all_matches.csv not found"
    echo "Please ensure the CSV file is in the progress/ directory"
    exit 1
fi

# Count matches
match_count=$(wc -l < progress/atp_all_matches.csv)
echo ""
echo "Found $match_count matches in input file"

# Ask if user wants to test first
echo ""
echo "Would you like to test on a single match first? (recommended)"
read -p "Test first? (y/n): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Running test..."
    python3 test_stats_extraction.py
    echo ""
    read -p "Test complete. Continue with full collection? (y/n): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Cancelled by user"
        exit 0
    fi
fi

# Run collector
echo ""
echo "Starting full collection..."
echo "This will take approximately 1-2 hours"
echo ""
read -p "Run in background? (y/n): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    nohup python3 atp_stats_collector_fast.py > stats_collection.log 2>&1 &
    PID=$!
    echo "✓ Started in background (PID: $PID)"
    echo ""
    echo "Monitor progress with:"
    echo "  tail -f stats_collection.log"
    echo ""
    echo "Check if still running:"
    echo "  ps -p $PID"
else
    python3 atp_stats_collector_fast.py
fi

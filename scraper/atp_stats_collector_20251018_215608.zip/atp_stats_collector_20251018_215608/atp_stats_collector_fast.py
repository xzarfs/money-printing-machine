#!/usr/bin/env python3
"""
ATP Match Statistics Collector - FAST VERSION
Optimized for faster collection with minimal delays.
Use on a different computer/IP to avoid rate limiting.
"""

import cloudscraper
from bs4 import BeautifulSoup
import csv
import json
import time
import random
from datetime import datetime
import os
import sys

# Configuration - OPTIMIZED FOR SPEED
MIN_DELAY = 1.0  # Minimum delay between requests (was 5.0)
MAX_DELAY = 2.0  # Maximum delay between requests (was 10.0)
BATCH_SIZE = 50  # Save progress every N matches
MAX_RETRIES = 2  # Reduced retries (was 3)
RETRY_DELAY = 30  # Delay after error (was 60)

# File paths
INPUT_FILE = 'progress/atp_all_matches.csv'
OUTPUT_FILE = 'progress/atp_match_statistics.csv'
PROGRESS_FILE = 'progress/stats_progress_fast.json'

# Statistics to collect (per player)
STAT_FIELDS = {
    'service': [
        'aces', 'double_faults', 'first_serve_pct', 
        'first_serve_points_won', 'second_serve_points_won',
        'service_games_won', 'break_points_saved'
    ],
    'return': [
        'first_serve_return_won', 'second_serve_return_won',
        'break_points_converted', 'return_games_won'
    ],
    'points': [
        'total_points_won', 'winners', 'unforced_errors',
        'net_points_won', 'max_points_in_row', 'max_games_in_row'
    ]
}

def create_scraper():
    """Create a cloudscraper instance with browser emulation"""
    return cloudscraper.create_scraper(
        browser={
            'browser': 'chrome',
            'platform': 'windows',
            'mobile': False
        }
    )

def load_progress():
    """Load progress from file if exists"""
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, 'r') as f:
                return json.load(f)
        except:
            return {'processed_urls': [], 'last_index': 0}
    return {'processed_urls': [], 'last_index': 0}

def save_progress(progress):
    """Save current progress"""
    os.makedirs('progress', exist_ok=True)
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(progress, f, indent=2)

def extract_stat_value(stat_element):
    """Extract numeric value from stat element"""
    if not stat_element:
        return ''
    
    text = stat_element.get_text(strip=True)
    # Handle percentages, fractions, numbers
    if '%' in text:
        return text.replace('%', '').strip()
    elif '/' in text:
        # For stats like "34/56" or "5/8"
        return text
    else:
        # Just a number
        return text.strip()

def extract_stats(soup, player1_name, player2_name):
    """
    Extract statistics for both players from match stats page
    
    Returns dict with keys: p1_<stat>, p2_<stat>
    """
    stats = {}
    
    # Initialize all stats to empty
    for category in STAT_FIELDS.values():
        for stat in category:
            stats[f'p1_{stat}'] = ''
            stats[f'p2_{stat}'] = ''
    
    try:
        # Strategy: Find stat rows, extract values for both players
        # Common patterns:
        # - Table rows with stat name and two values
        # - Stat containers with player-specific sections
        
        # Look for stats table or container
        stats_container = soup.find('div', class_=lambda x: x and ('stats' in x.lower() or 'match-stats' in x.lower()))
        
        if not stats_container:
            # Try alternative: look for all stat rows
            stats_container = soup
        
        # Find all stat rows/items
        # Pattern 1: Look for rows with data for both players
        stat_rows = stats_container.find_all(['tr', 'div'], class_=lambda x: x and ('stat' in x.lower() or 'row' in x.lower()))
        
        if not stat_rows:
            # Pattern 2: Look for specific stat elements
            stat_rows = stats_container.find_all(['div', 'tr'])
        
        # Map of stat names to our field names
        stat_mapping = {
            # Service stats
            'aces': 'aces',
            'ace': 'aces',
            'double faults': 'double_faults',
            'double fault': 'double_faults',
            '1st serve': 'first_serve_pct',
            'first serve': 'first_serve_pct',
            '1st serve points won': 'first_serve_points_won',
            'first serve points won': 'first_serve_points_won',
            '2nd serve points won': 'second_serve_points_won',
            'second serve points won': 'second_serve_points_won',
            'service games won': 'service_games_won',
            'break points saved': 'break_points_saved',
            # Return stats
            '1st serve return points won': 'first_serve_return_won',
            'first serve return points won': 'first_serve_return_won',
            '2nd serve return points won': 'second_serve_return_won',
            'second serve return points won': 'second_serve_return_won',
            'break points converted': 'break_points_converted',
            'return games won': 'return_games_won',
            # Point stats
            'total points won': 'total_points_won',
            'winners': 'winners',
            'unforced errors': 'unforced_errors',
            'net points won': 'net_points_won',
            'max points in a row': 'max_points_in_row',
            'max games in a row': 'max_games_in_row',
        }
        
        # Process each row looking for stats
        for row in stat_rows:
            row_text = row.get_text(strip=True).lower()
            
            # Find which stat this row represents
            matched_stat = None
            for pattern, field_name in stat_mapping.items():
                if pattern in row_text:
                    matched_stat = field_name
                    break
            
            if matched_stat:
                # Extract values for both players
                # Look for numeric values in the row
                values = row.find_all(['td', 'span', 'div'], class_=lambda x: x and ('value' in x.lower() or 'stat' in x.lower() or 'number' in x.lower()))
                
                if not values:
                    # Try finding all td/span elements
                    values = row.find_all(['td', 'span'])
                
                # Filter to get numeric values
                numeric_values = []
                for val in values:
                    val_text = val.get_text(strip=True)
                    # Check if it looks like a number or percentage
                    if any(c.isdigit() for c in val_text):
                        numeric_values.append(extract_stat_value(val))
                
                # Assign to players (usually first value is player 1, second is player 2)
                if len(numeric_values) >= 2:
                    stats[f'p1_{matched_stat}'] = numeric_values[0]
                    stats[f'p2_{matched_stat}'] = numeric_values[1]
                elif len(numeric_values) == 1:
                    # Sometimes only one value shown
                    stats[f'p1_{matched_stat}'] = numeric_values[0]
    
    except Exception as e:
        print(f"    ⚠ Error extracting stats: {e}")
    
    return stats

def collect_match_stats(scraper, stats_url, player1, player2, retry_count=0):
    """
    Collect statistics from a single match page
    
    Returns: dict with all statistics or None if failed
    """
    try:
        # Add random delay
        delay = random.uniform(MIN_DELAY, MAX_DELAY)
        time.sleep(delay)
        
        response = scraper.get(stats_url, timeout=30)
        
        if response.status_code == 429:
            if retry_count < MAX_RETRIES:
                wait_time = RETRY_DELAY * (retry_count + 1)
                print(f"    ⚠ Rate limited (429). Waiting {wait_time}s before retry {retry_count + 1}/{MAX_RETRIES}...")
                time.sleep(wait_time)
                return collect_match_stats(scraper, stats_url, player1, player2, retry_count + 1)
            else:
                print(f"    ✗ Max retries reached. Skipping.")
                return None
        
        if response.status_code != 200:
            print(f"    ✗ HTTP {response.status_code}")
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        stats = extract_stats(soup, player1, player2)
        
        return stats
    
    except Exception as e:
        print(f"    ✗ Error: {e}")
        if retry_count < MAX_RETRIES:
            time.sleep(RETRY_DELAY)
            return collect_match_stats(scraper, stats_url, player1, player2, retry_count + 1)
        return None

def initialize_output_file():
    """Create output CSV with headers if it doesn't exist"""
    if os.path.exists(OUTPUT_FILE):
        return
    
    os.makedirs('progress', exist_ok=True)
    
    # Create headers
    headers = [
        'tournament', 'tournament_dates', 'match_date', 'round',
        'player1', 'player2', 'score', 'match_time'
    ]
    
    # Add player 1 stats
    for category in STAT_FIELDS.values():
        for stat in category:
            headers.append(f'p1_{stat}')
    
    # Add player 2 stats
    for category in STAT_FIELDS.values():
        for stat in category:
            headers.append(f'p2_{stat}')
    
    headers.append('stats_url')
    
    with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
    
    print(f"✓ Created output file: {OUTPUT_FILE}")

def main():
    """Main execution function"""
    print("=" * 80)
    print("ATP Match Statistics Collector - FAST VERSION")
    print("=" * 80)
    print(f"Configuration:")
    print(f"  - Delay between requests: {MIN_DELAY}-{MAX_DELAY} seconds")
    print(f"  - Batch size: {BATCH_SIZE} matches")
    print(f"  - Max retries: {MAX_RETRIES}")
    print("=" * 80)
    
    # Load input matches
    if not os.path.exists(INPUT_FILE):
        print(f"✗ Input file not found: {INPUT_FILE}")
        return
    
    matches = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        matches = list(reader)
    
    print(f"\n✓ Loaded {len(matches)} matches from {INPUT_FILE}")
    
    # Load progress
    progress = load_progress()
    processed_urls = set(progress.get('processed_urls', []))
    start_index = progress.get('last_index', 0)
    
    if processed_urls:
        print(f"✓ Resuming from match {start_index + 1} ({len(processed_urls)} already processed)")
    
    # Initialize output file
    initialize_output_file()
    
    # Create scraper
    scraper = create_scraper()
    print(f"✓ Scraper initialized\n")
    
    # Process matches
    start_time = time.time()
    successful = 0
    failed = 0
    skipped = 0
    
    for i, match in enumerate(matches[start_index:], start=start_index):
        stats_url = match.get('stats_url', '').strip()
        
        if not stats_url:
            skipped += 1
            continue
        
        if stats_url in processed_urls:
            skipped += 1
            continue
        
        player1 = match.get('player1', '')
        player2 = match.get('player2', '')
        
        # Progress indicator
        elapsed = time.time() - start_time
        rate = (i - start_index + 1) / elapsed if elapsed > 0 else 0
        eta = (len(matches) - i - 1) / rate if rate > 0 else 0
        
        print(f"[{i+1}/{len(matches)}] {match.get('tournament', '')} - {player1} vs {player2}")
        print(f"  Rate: {rate:.2f} matches/sec | ETA: {eta/60:.1f} min | Success: {successful} | Failed: {failed}")
        
        # Collect stats
        stats = collect_match_stats(scraper, stats_url, player1, player2)
        
        if stats:
            # Prepare row
            row = [
                match.get('tournament', ''),
                match.get('tournament_dates', ''),
                match.get('match_date', ''),
                match.get('round', ''),
                player1,
                player2,
                match.get('score', ''),
                match.get('match_time', '')
            ]
            
            # Add player 1 stats
            for category in STAT_FIELDS.values():
                for stat in category:
                    row.append(stats.get(f'p1_{stat}', ''))
            
            # Add player 2 stats
            for category in STAT_FIELDS.values():
                for stat in category:
                    row.append(stats.get(f'p2_{stat}', ''))
            
            row.append(stats_url)
            
            # Write to CSV
            with open(OUTPUT_FILE, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(row)
            
            successful += 1
            print(f"  ✓ Stats collected")
        else:
            failed += 1
        
        # Update progress
        processed_urls.add(stats_url)
        
        # Save progress periodically
        if (i + 1) % BATCH_SIZE == 0:
            progress['processed_urls'] = list(processed_urls)
            progress['last_index'] = i + 1
            save_progress(progress)
            print(f"\n  💾 Progress saved ({successful} successful, {failed} failed, {skipped} skipped)\n")
    
    # Final progress save
    progress['processed_urls'] = list(processed_urls)
    progress['last_index'] = len(matches)
    save_progress(progress)
    
    # Summary
    total_time = time.time() - start_time
    print("\n" + "=" * 80)
    print("COLLECTION COMPLETE")
    print("=" * 80)
    print(f"Total time: {total_time/60:.1f} minutes ({total_time:.0f} seconds)")
    print(f"Successful: {successful}")
    print(f"Failed: {failed}")
    print(f"Skipped: {skipped}")
    print(f"Average rate: {successful/total_time:.2f} matches/second")
    print(f"Output file: {OUTPUT_FILE}")
    print("=" * 80)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠ Interrupted by user. Progress has been saved.")
        sys.exit(0)
    except Exception as e:
        print(f"\n\n✗ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

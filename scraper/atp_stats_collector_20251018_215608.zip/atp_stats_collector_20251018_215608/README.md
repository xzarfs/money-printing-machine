# 🎾 ATP 2025 Match Statistics Collector

## 📁 Files to Transfer to New Computer

Copy these files to run on another computer:

### Required Files:
1. **`atp_stats_collector_fast.py`** - Main fast collector (1-2 hour runtime)
2. **`progress/atp_all_matches.csv`** - Input data (2,441 matches)
3. **`test_stats_extraction.py`** - Test script (optional but recommended)

### Files Created During Execution:
- `progress/atp_match_statistics.csv` - Output with all statistics
- `progress/stats_progress_fast.json` - Progress tracking (auto-created)
- `debug_single_match.html` - HTML dump for debugging (from test script)

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
pip install cloudscraper beautifulsoup4 lxml

# 2. Create directory structure
mkdir -p progress

# 3. Copy files
# - atp_stats_collector_fast.py
# - progress/atp_all_matches.csv

# 4. (Optional) Test on single match first
python3 test_stats_extraction.py

# 5. Run the full collector
python3 atp_stats_collector_fast.py
```

---

## ⚡ Speed Comparison

| Version | Delay | Expected Time | Matches/Hour |
|---------|-------|---------------|--------------|
| Original | 5-10s | 4-7 hours | ~350-600 |
| **Fast** | **1-2s** | **1-2 hours** | **~1,200-2,400** |

**Fast version is 3-4x faster!**

---

## 📊 What Gets Collected

For each of 2,441 matches, we collect **32 statistics** (16 per player):

### Service Statistics (7 per player):
- Aces
- Double Faults
- First Serve %
- First Serve Points Won
- Second Serve Points Won
- Service Games Won
- Break Points Saved

### Return Statistics (4 per player):
- First Serve Return Won
- Second Serve Return Won
- Break Points Converted
- Return Games Won

### Point Statistics (5 per player):
- Total Points Won
- Winners
- Unforced Errors
- Net Points Won
- Max Points/Games in a Row

**Total: ~78,000 data points**

---

## 💻 System Requirements

- **Python**: 3.7 or higher
- **RAM**: 512MB minimum
- **Disk Space**: 50MB for output files
- **Internet**: Stable connection (1-2 hours)
- **OS**: Linux, macOS, or Windows

---

## 🔧 Configuration

Edit `atp_stats_collector_fast.py` if needed:

```python
# Line 17-18: Adjust delays
MIN_DELAY = 1.0  # Minimum seconds between requests
MAX_DELAY = 2.0  # Maximum seconds between requests

# Line 19-21: Other settings
BATCH_SIZE = 50      # Save progress every N matches
MAX_RETRIES = 2      # Retry attempts on failure
RETRY_DELAY = 30     # Seconds to wait before retry
```

**If you get rate limited (HTTP 429):**
- Increase `MIN_DELAY` to 2.0 or 3.0
- Increase `MAX_DELAY` to 4.0 or 5.0

---

## 📈 Progress Monitoring

### Real-time Display:
```
[1234/2441] Australian Open - Sinner vs Djokovic
  Rate: 0.67 matches/sec | ETA: 30.1 min | Success: 1150 | Failed: 84
  ✓ Stats collected
```

### Check Progress Anytime:
```bash
# Count collected matches
wc -l progress/atp_match_statistics.csv

# View latest collections
tail -n 10 progress/atp_match_statistics.csv

# Monitor in real-time
tail -f stats_collection.log
```

---

## 🔄 Resume Capability

The script **automatically saves progress** every 50 matches.

If interrupted:
```bash
# Just run it again - it resumes automatically
python3 atp_stats_collector_fast.py
```

Progress is saved to: `progress/stats_progress_fast.json`

---

## 🎯 Expected Results

### After 1-2 Hours:
- **File**: `progress/atp_match_statistics.csv`
- **Rows**: ~2,400+ (depending on successful collections)
- **Columns**: 40
  - 8 match info columns
  - 16 player 1 stat columns
  - 16 player 2 stat columns
  - 1 stats_url column
- **Size**: ~500KB-1MB

### Success Rate:
- **Best case**: 95-98% success (2,320-2,390 matches)
- **Good case**: 85-90% success (2,075-2,195 matches)
- **Acceptable**: 75-80% success (1,830-1,950 matches)

Some matches may fail due to:
- Missing stats pages (walkover/retirement)
- Page structure changes
- Temporary connection issues

---

## 🆘 Troubleshooting

### Problem: Import errors
```
ImportError: No module named 'cloudscraper'
```
**Solution:**
```bash
pip install cloudscraper beautifulsoup4 lxml
```

### Problem: File not found
```
FileNotFoundError: progress/atp_all_matches.csv
```
**Solution:**
```bash
mkdir -p progress
# Copy atp_all_matches.csv to progress/ directory
```

### Problem: Rate limited (HTTP 429)
```
⚠ Rate limited (429). Waiting 30s before retry...
```
**Solution:**
- Wait 1-2 hours and try again
- Run on different network/VPN
- Increase delays in config (lines 17-18)

### Problem: Slow performance
**Solution:**
```python
# Decrease delays for faster collection (riskier)
MIN_DELAY = 0.5  # Was 1.0
MAX_DELAY = 1.0  # Was 2.0
```

### Problem: Too many failures
**Solution:**
```python
# Increase delays for better reliability
MIN_DELAY = 2.0  # Was 1.0
MAX_DELAY = 4.0  # Was 2.0
```

---

## 📦 Complete File List

### Before Running:
```
atp_stats_collector_fast.py      # Main script
test_stats_extraction.py          # Test script (optional)
progress/
  └── atp_all_matches.csv         # Input (2,441 matches)
```

### After Running:
```
atp_stats_collector_fast.py
test_stats_extraction.py
progress/
  ├── atp_all_matches.csv         # Input
  ├── atp_match_statistics.csv    # OUTPUT ✓
  └── stats_progress_fast.json    # Progress tracking
stats_collection.log                # Log file (if using nohup)
debug_single_match.html             # Debug file (if ran test)
```

---

## 🎓 Usage Examples

### Basic Run:
```bash
python3 atp_stats_collector_fast.py
```

### Background Run (Linux/Mac):
```bash
nohup python3 atp_stats_collector_fast.py > stats_collection.log 2>&1 &
```

### Background Run (Windows):
```bash
start /B python atp_stats_collector_fast.py > stats_collection.log 2>&1
```

### Monitor Background Job:
```bash
tail -f stats_collection.log
```

### Test First (Recommended):
```bash
# Test on single match to verify everything works
python3 test_stats_extraction.py

# If test passes, run full collection
python3 atp_stats_collector_fast.py
```

---

## 📊 Data Structure

### Input (atp_all_matches.csv):
```csv
tournament,tournament_dates,match_date,round,player1,player2,score,match_time,stats_url
Australian Open,Melbourne / 12.01. - 26.01.,Sunday 12 January,First Round,J.Mensik,D.Lajovic,...
```

### Output (atp_match_statistics.csv):
```csv
tournament,tournament_dates,match_date,round,player1,player2,score,match_time,p1_aces,p1_double_faults,...,p2_aces,p2_double_faults,...,stats_url
Australian Open,Melbourne / 12.01. - 26.01.,Sunday 12 January,First Round,J.Mensik,D.Lajovic,...,5,2,65%,...,3,4,58%,...,...
```

---

## ✅ Pre-Flight Checklist

Before running on new computer:

- [ ] Python 3.7+ installed (`python3 --version`)
- [ ] Dependencies installed (`pip list | grep -E "cloudscraper|beautifulsoup4|lxml"`)
- [ ] `atp_stats_collector_fast.py` file present
- [ ] `progress/atp_all_matches.csv` file present (2,441 rows)
- [ ] `progress/` directory exists
- [ ] Stable internet connection
- [ ] 2-3 hours of available time
- [ ] Not currently rate limited (test with `test_stats_extraction.py`)

After completion:

- [ ] `progress/atp_match_statistics.csv` exists
- [ ] File has 2,000+ rows
- [ ] File has 40 columns
- [ ] No errors in last 100 lines of output
- [ ] Stats look reasonable (e.g., aces < 50, serve % < 100)

---

## 🎯 Success Metrics

| Metric | Target | Good | Acceptable |
|--------|--------|------|------------|
| Completion Rate | 95%+ | 85-95% | 75-85% |
| Matches Collected | 2,300+ | 2,000-2,300 | 1,800-2,000 |
| Execution Time | <90 min | 90-120 min | 120-150 min |
| Error Rate | <5% | 5-15% | 15-25% |

---

## 📞 Support

If you encounter issues:

1. **Check the log**: Look for error messages
2. **Run test script**: `python3 test_stats_extraction.py`
3. **Verify input**: Ensure CSV has 2,441 rows
4. **Check network**: Test internet connection
5. **Adjust config**: Try slower delays if getting errors

---

## 🎉 After Collection

Once complete, you'll have comprehensive ATP 2025 statistics ready for:

- **Performance Analysis**: Compare player statistics
- **Match Prediction**: Use historical stats for modeling
- **Tournament Insights**: Analyze patterns across events
- **Player Comparison**: Head-to-head statistical analysis
- **Data Visualization**: Create charts and dashboards

**Happy analyzing! 🎾📊**

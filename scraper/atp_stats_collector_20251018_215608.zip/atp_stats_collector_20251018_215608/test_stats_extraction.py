#!/usr/bin/env python3
"""
Test script to verify stats extraction on a single match
Use this to test on the new computer before running full collection
"""

import cloudscraper
from bs4 import BeautifulSoup
import csv

def test_single_match():
    """Test stats extraction on one match"""
    
    print("=" * 70)
    print("ATP Stats Collector - Single Match Test")
    print("=" * 70)
    
    # Read first match from CSV
    with open('progress/atp_all_matches.csv', 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        match = next(reader)
    
    print(f"\nTesting match:")
    print(f"  Tournament: {match['tournament']}")
    print(f"  Match: {match['player1']} vs {match['player2']}")
    print(f"  Score: {match['score']}")
    print(f"  Stats URL: {match['stats_url']}\n")
    
    # Create scraper
    print("Creating scraper...")
    scraper = cloudscraper.create_scraper(
        browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
    )
    
    # Fetch page
    print("Fetching match stats page...")
    response = scraper.get(match['stats_url'], timeout=30)
    
    print(f"Response: HTTP {response.status_code}")
    
    if response.status_code == 429:
        print("\n⚠ Rate limited (HTTP 429)")
        print("Recommendations:")
        print("  1. Wait 1-2 hours and try again")
        print("  2. Run on different computer/network")
        print("  3. Use VPN if available")
        return
    
    if response.status_code != 200:
        print(f"\n✗ Error: Unexpected status code {response.status_code}")
        return
    
    print(f"✓ Page loaded successfully ({len(response.text):,} bytes)\n")
    
    # Parse HTML
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Save for inspection
    with open('debug_single_match.html', 'w', encoding='utf-8') as f:
        f.write(response.text)
    print("✓ Saved HTML to: debug_single_match.html\n")
    
    # Look for stat keywords
    text = soup.get_text().lower()
    
    keywords = {
        'Service Stats': ['aces', 'double faults', 'first serve', '1st serve', 'service games'],
        'Return Stats': ['return points', 'break points converted', 'return games'],
        'Point Stats': ['total points', 'winners', 'unforced errors', 'net points']
    }
    
    print("Checking for statistics keywords:\n")
    
    all_found = True
    for category, terms in keywords.items():
        print(f"{category}:")
        category_found = False
        for term in terms:
            if term in text:
                print(f"  ✓ {term}")
                category_found = True
            else:
                print(f"  ✗ {term}")
        
        if not category_found:
            all_found = False
        print()
    
    # Try to find stat structure
    print("Looking for stats structure...")
    
    # Common patterns
    patterns = [
        ('stats', 'div', {'class': lambda x: x and 'stats' in x.lower()}),
        ('match-stats', 'div', {'class': lambda x: x and 'match-stats' in x.lower()}),
        ('stat-row', 'tr', {'class': lambda x: x and 'stat' in x.lower()}),
        ('data-table', 'table', {}),
    ]
    
    for name, tag, attrs in patterns:
        elements = soup.find_all(tag, attrs)
        if elements:
            print(f"  ✓ Found {len(elements)} '{name}' elements")
        else:
            print(f"  ✗ No '{name}' elements found")
    
    print("\n" + "=" * 70)
    
    if response.status_code == 200 and all_found:
        print("✓ TEST PASSED")
        print("Stats page is accessible and contains expected data.")
        print("You can now run the full collector:")
        print("  python3 atp_stats_collector_fast.py")
    elif response.status_code == 200:
        print("⚠ PARTIAL SUCCESS")
        print("Page is accessible but some stats keywords missing.")
        print("Check debug_single_match.html to verify stats structure.")
        print("You may need to adjust the extraction logic.")
    else:
        print("✗ TEST FAILED")
        print("Cannot access stats page. Check connection and rate limiting.")
    
    print("=" * 70)

if __name__ == '__main__':
    try:
        test_single_match()
    except FileNotFoundError:
        print("\n✗ Error: progress/atp_all_matches.csv not found")
        print("Make sure you have the input CSV file in the progress/ directory")
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
